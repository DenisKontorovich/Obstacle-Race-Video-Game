﻿using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
using Animation2D;

namespace TowerTrek
{
    public class MainGame : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        //Store both the current and previous mouse states for user input
        MouseState mouse;
        MouseState prevMouse;

        //Keyboard state variables
        KeyboardState kb;
        KeyboardState prevKb;

        //The random object allowing for random number generation during Shuffle
        Random rng = new Random();

        float powerUpTimer;
        float difficultyTimer;
        float spikeWallHitTimer = 20;
        float dTravelledTimer;

        const int MAIN_MENU = 0;
        const int INSTRUCTIONS = 1;
        const int OPTIONS = 2;
        const int SCOREBOARD = 3;
        const int GAMEPLAY = 4;
        const int GAMEOVER = 5;
        const int POSTGAME = 6;
        int gameState = MAIN_MENU;

        int screenWidth;
        int screenHeight;
        int platformNum = 0;

        float acceleration = 0.2f;
        float friction = 0f;

        float playerTransperency = 1f;
        //int transperency = 1;
        int direction;

        Texture2D gameplayBgImg;
        Texture2D playerImg;
        Texture2D platformImg;
        Texture2D blankImg;
        Texture2D leftWallSpikesImg;
        Texture2D rightWallSpikesImg;
        Texture2D lavaImg;
        Texture2D livesImg;
        Texture2D blackBoxImg;
        Texture2D leftWallImg;
        Texture2D rightWallImg;
        Texture2D jumpBarImg;
        Texture2D powerBarImg;
        Texture2D mudPlatformImg;
        Texture2D iceyPlatformImg;
        Texture2D spikesPlatformImg;
        Texture2D powerUpImg;
        Texture2D healthUpImg;
        Texture2D titleBgImg;
        Texture2D plusImg;
        Texture2D minusImg;
        Texture2D whitePageImg;
        Texture2D backArrowImg;
        Texture2D instructionsBgImg;
        Texture2D optionsBgImg;

        Rectangle plusRec;
        Rectangle minusRec;
        Rectangle playerRec;
        Rectangle gameplayBgRec1;
        Rectangle gameplayBgRec2;
        //Rectangle platformRec;
        Rectangle[] leftWallSpikesRec = new Rectangle[6];
        Rectangle[] rightWallSpikesRec = new Rectangle[6];
        Rectangle lavaRec;
        Rectangle[] livesRec = new Rectangle[3];
        Rectangle[] selectionBoxRec = new Rectangle[4];
        Rectangle leftWallRec;
        Rectangle rightWallRec;
        Rectangle playerFeetRec;
        Rectangle[] platformRec = new Rectangle[5];
        Rectangle startingPlatformRec;
        Rectangle jumpBarOutline;
        Rectangle jumpBarRec;
        Rectangle powerBarOutline;
        Rectangle powerBarRec;
        Rectangle mudPlatformRec;
        Rectangle iceyPlatformRec;
        Rectangle spikesPlatformRec;
        Rectangle powerUpRec;
        Rectangle healthUpRec;
        Rectangle titleBgRec;
        //Rectangle pSpikesRec;
        Rectangle whiteRec;
        Rectangle backArrowRec;
        Rectangle instructionsBgRec;
        Rectangle optionsBgRec;

        SpriteFont gameLabel;

        Vector2 scoreLoc = new Vector2(120, 0);
        Vector2 highScoreLoc = new Vector2(120, 20);
        Vector2 dTravelledLoc = new Vector2(120, 40);
        Vector2[] platformLoc = new Vector2[5];
        Vector2 iceyPlatformLoc;
        Vector2 mudPlatformLoc;
        Vector2 spikesPlatformLoc;
        Vector2 playerLoc;
        Vector2 platformSpeed;
        Vector2 playerVelocity;
        Vector2 gravity = new Vector2(0f, 9.81f / 60f);
        Vector2 powerUpLoc;
        Vector2 healthUpLoc;
        Vector2 instructionsLoc;
        Vector2 optionsLoc;
        Vector2 scoreboardLoc;
        Vector2 startGameLoc;
        Vector2 audioVolumeLoc = new Vector2(350, 250);
        Vector2 pauseLoc;
        Vector2 moveLeftLoc = new Vector2(100, 300);
        Vector2 moveRightLoc = new Vector2(100, 370);
        Vector2 jumpLoc = new Vector2(100, 430);

        int score = 0;
        int highScore;
        int dTravelled = 0;
        int lives = 3;
        int[] platformType = new int[5];

        //Store the vertical and horizonatal speeds for jumping and moving
        float jumpSpeed = -20f;
        float maxSpeed = 15f;

        string instructionsOutput = "INSTRUCTIONS";
        string optionsOutput = "OPTIONS";
        string scoreboardOutput = "SCOREBOARD";
        string playGameOutput = "PLAY GAME";
        string scoreOutput = "Score: ";
        string highScoreOutput = "High Score: ";
        string startGameOutput = "START GAME ";
        string dTravelledOutput = "Distance: ";
        string pauseOutput = "PAUSE";

        bool starting = true;

        int scrollingSpeed = 1;
        int jumpCounter = 0;

        int hitCounter = 0;
        int spikeWallHitCounter = 0;
        bool calcScore = false;
        bool powerUp = false;

        int jumpsAvailable = 2;
        int difficulty = 0;

        const int REG = 0;
        const int MUD = 1;
        const int ICE = 2;
        const int SPIKE = 3;

        int platTypeNum;
        float audioVolume = 0.5f;
        int maxVolume = 1;

        bool pause = false;

        string moveLeft;
        string moveRight;
        string moveUp;

        public MainGame()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            //Allows cursor to be seen by user in game
            this.IsMouseVisible = true;

            //change the length and width of the screen
            this.graphics.PreferredBackBufferWidth = 700;
            this.graphics.PreferredBackBufferHeight = 752;
            this.graphics.ApplyChanges();
            screenWidth = graphics.GraphicsDevice.Viewport.Width;
            screenHeight = graphics.GraphicsDevice.Viewport.Height;

            base.Initialize();
        }


        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //Load all background images
            gameplayBgImg = Content.Load<Texture2D>("Images/Backgrounds/brickBackground2");
            playerImg = Content.Load<Texture2D>("Images/Sprites/Player");
            platformImg = Content.Load<Texture2D>("Images/Sprites/Platform");
            blankImg = Content.Load<Texture2D>("Images/Sprites/whiteBoxPng");
            leftWallSpikesImg = Content.Load<Texture2D>("Images/Backgrounds/LeftWallSpikes");
            rightWallSpikesImg = Content.Load<Texture2D>("Images/Backgrounds/rightWallSpikes");
            lavaImg = Content.Load<Texture2D>("Images/Backgrounds/lava");
            livesImg = Content.Load<Texture2D>("Images/Sprites/lives");
            blackBoxImg = Content.Load<Texture2D>("Images/Sprites/blackBox");
            leftWallImg = Content.Load<Texture2D>("Images/Backgrounds/leftBrickWall");
            rightWallImg = Content.Load<Texture2D>("Images/Backgrounds/rightBrickWall");
            jumpBarImg = Content.Load<Texture2D>("Images/Sprites/blueBox");
            powerBarImg = Content.Load<Texture2D>("Images/Sprites/pinkBox");
            mudPlatformImg = Content.Load<Texture2D>("Images/Sprites/mudPlatform");
            iceyPlatformImg = Content.Load<Texture2D>("Images/Sprites/iceyPlatform");
            spikesPlatformImg = Content.Load<Texture2D>("Images/Sprites/spikePlatform");
            powerUpImg = Content.Load<Texture2D>("Images/Sprites/powerUp");
            healthUpImg = Content.Load<Texture2D>("Images/Sprites/healthUp");
            titleBgImg = Content.Load<Texture2D>("Images/Backgrounds/titleBackground");
            plusImg = Content.Load<Texture2D>("Images/Sprites/plusSign");
            minusImg = Content.Load<Texture2D>("Images/Sprites/minusSign");
            whitePageImg = Content.Load<Texture2D>("Images/Backgrounds/whiteBox");
            backArrowImg = Content.Load<Texture2D>("Images/Sprites/backArrow");
            instructionsBgImg = Content.Load<Texture2D>("Images/Backgrounds/instructionsBackground");
            optionsBgImg = Content.Load<Texture2D>("Images/Backgrounds/optionsBackground");

            gameLabel = Content.Load<SpriteFont>("Fonts/gameLabelFont");

            //Load all Rectamgles
            gameplayBgRec1 = new Rectangle(0, 0, screenWidth, screenHeight);
            gameplayBgRec2 = new Rectangle(0, -screenHeight, screenWidth, screenHeight);
            titleBgRec = new Rectangle(0, 0, screenWidth, screenHeight);

            lavaRec = new Rectangle(0, screenHeight - (int)(lavaImg.Height * 1.5), screenWidth, (int)(lavaImg.Height * 1.5));

            leftWallRec = new Rectangle(0, 0, 60, (int)(leftWallImg.Height));
            rightWallRec = new Rectangle(screenWidth - 60, 0, 75, (int)(rightWallImg.Height));

            powerUpRec = new Rectangle(rng.Next(100, 460), rng.Next(-1000, -500), (int)(powerUpImg.Width / 13), (int)(powerUpImg.Height / 14));
            healthUpRec = new Rectangle(rng.Next(100, 460), rng.Next(-1000, -500), (int)(healthUpImg.Width / 20), (int)(healthUpImg.Height / 20));

            for (int i = 0; i < leftWallSpikesRec.Length; i++)
            {
                leftWallSpikesRec[i] = new Rectangle(-2 + 60, 0, (int)(leftWallSpikesImg.Width / 2.5), (int)(leftWallSpikesImg.Height));

                if (i != 0)
                {
                    leftWallSpikesRec[i] = new Rectangle(-2 + 60, (leftWallSpikesImg.Height * i) - (7 * i), (int)(leftWallSpikesImg.Width / 2.5), (int)(leftWallSpikesImg.Height));
                }
            }
            for (int i = 0; i < rightWallSpikesRec.Length; i++)
            {
                rightWallSpikesRec[i] = new Rectangle(screenWidth - 60 - (int)(leftWallSpikesImg.Width / 2.5) + 2, 0, (int)(rightWallSpikesImg.Width / 2.5), (int)(rightWallSpikesImg.Height));

                if (i != 0)
                {
                    rightWallSpikesRec[i] = new Rectangle(screenWidth - 60 - (int)(leftWallSpikesImg.Width / 2.5) + 2, (rightWallSpikesImg.Height * i) - (7 * i), (int)(rightWallSpikesImg.Width / 2.5), (int)(rightWallSpikesImg.Height));
                }
            }

            for (int i = 0; i < livesRec.Length; i++)
            {
                livesRec[i] = new Rectangle(screenWidth - 175 - ((int)(livesImg.Width / 2) * i), 0, (int)(livesImg.Width / 2.2), (int)(livesImg.Height / 2.2));
            }

            for (int i = 0; i < selectionBoxRec.Length; i++)
            {
                selectionBoxRec[i] = new Rectangle((screenWidth / 2) - ((int)(blackBoxImg.Width / 5.5) / 2), 300 + ((int)(blackBoxImg.Height / 9) * i) + (35 * i), (int)(blackBoxImg.Width / 5.5), (int)(blackBoxImg.Height / 9));
            }


            playerVelocity = new Vector2(0, 0);

            for (int i = 1; i < platformRec.Length; i++)
            {
                platformRec[i] = new Rectangle(rng.Next(120, 480), 0 - (((screenHeight - lavaRec.Height) / 4) * i), (int)(platformImg.Width / 2.5), (int)(platformImg.Height / 1.2));
                platformLoc[i] = new Vector2(platformRec[i].X, platformRec[i].Y);
            }
            
            mudPlatformLoc = new Vector2(mudPlatformRec.X, mudPlatformRec.Y);
            iceyPlatformLoc = new Vector2(iceyPlatformRec.X, iceyPlatformRec.Y);
            spikesPlatformLoc = new Vector2(spikesPlatformRec.X, spikesPlatformRec.Y);
            powerUpLoc = new Vector2(powerUpRec.X, powerUpRec.Y);
            healthUpLoc = new Vector2(healthUpRec.X, healthUpRec.Y);

            playerRec = new Rectangle(300, platformRec[0].X + (int)(playerImg.Height / 3.8), (int)(playerImg.Width / 3.8), (int)(playerImg.Height / 3.8));
            playerLoc = new Vector2(playerRec.X, playerRec.Y);
            playerFeetRec = new Rectangle(playerRec.X + 12, playerRec.Y + 60, playerRec.Width - 48, playerRec.Height - 60);
            //pSpikesRec = new Rectangle(spikesPlatformRec.X + 6, spikesPlatformRec.Y, (int)(spikesPlatformRec.Width / 1.09), (int)(spikesPlatformRec.Height / 1.82));

            jumpBarOutline = new Rectangle(5, 200, 40, 200);
            jumpBarRec = new Rectangle(5, 200, 40, 200);
            powerBarOutline = new Rectangle(655, 200, 40, 200);
            powerBarRec = new Rectangle(655, 200, 40, 200);

            platformSpeed = new Vector2(0, 2f);

            for(int i = 0; i < platformRec.Length; i++)
            {
                platformType[i] = REG;
            }

            instructionsLoc = new Vector2(selectionBoxRec[0].X, selectionBoxRec[0].Y);
            optionsLoc = new Vector2(selectionBoxRec[1].X, selectionBoxRec[1].Y);
            scoreboardLoc = new Vector2(selectionBoxRec[2].X, selectionBoxRec[2].Y);
            startGameLoc = new Vector2(selectionBoxRec[3].X, selectionBoxRec[3].Y);

            plusRec = new Rectangle(200,200,(int)(plusImg.Width / 8), (int)(plusImg.Height / 8));
            minusRec = new Rectangle(450, 200, (int)(minusImg.Width / 8), (int)(minusImg.Height / 8));
            whiteRec = new Rectangle(0, 200, screenWidth, 300);

            pauseLoc = new Vector2 (whiteRec.X, whiteRec.Y);

            backArrowRec = new Rectangle(0, screenHeight - (int)(backArrowImg.Height / 7), (int)(backArrowImg.Width / 7), (int)(backArrowImg.Height / 7));
            instructionsBgRec = new Rectangle(0,0, screenWidth, screenHeight);
            optionsBgRec = new Rectangle(0,0,screenWidth, screenHeight);
        }

        protected override void UnloadContent()
        {

        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            //Track the state of the keyboard
            prevKb = kb;
            kb = Keyboard.GetState();

            //Get the current mouse state
            prevMouse = mouse;
            mouse = Mouse.GetState();

            switch (gameState)
            {
                case MAIN_MENU:
                    {
                        if (NewMouseClick())
                        {
                            if (MouseClicked(selectionBoxRec[0]) == true)
                            {
                                gameState = INSTRUCTIONS;
                            }
                            else if (MouseClicked(selectionBoxRec[1]) == true)
                            {
                                gameState = OPTIONS;
                            }
                            else if (MouseClicked(selectionBoxRec[2]) == true)
                            {
                                gameState = SCOREBOARD;
                            }
                            else if (MouseClicked(selectionBoxRec[3]) == true)
                            {
                                gameState = GAMEPLAY;
                            }
                        }
                    }
                    break;
                case INSTRUCTIONS:
                    {
                        //spriteBatch.Draw(regBgImg, );
                        if(NewMouseClick())
                        {
                            if(MouseClicked(backArrowRec))
                            {
                                gameState = MAIN_MENU;
                            }
                        }
                    }
                    break;
                case OPTIONS:
                    {
                        if(NewMouseClick())
                        {
                            if (MouseClicked(plusRec))
                            {
                                if (audioVolume < 2)
                                { 
                                    audioVolume += 0.1f;
                                }
                            }

                            if (MouseClicked(minusRec))
                            {
                                if (audioVolume > 0)
                                {
                                    audioVolume -= 0.1f;
                                }
                            }

                            if (MouseClicked(backArrowRec))
                            {
                                gameState = MAIN_MENU;
                            }
                        }
                    }
                    break;
                case SCOREBOARD:
                    {
                        if (NewMouseClick())
                        {
                            if (MouseClicked(backArrowRec))
                            {
                                gameState = MAIN_MENU;
                            }
                        }
                    }
                    break;
                case GAMEPLAY:
                    {
                        if (pause == false)
                        {
                            difficultyTimer += (float)(gameTime.ElapsedGameTime.TotalSeconds);

                            IncreaseDifficulty();
                            ScrollScreen();
                            HorizontalMovement();

                            if(playerVelocity.X != 0)
                            {
                                if(playerVelocity.X > 0)
                                {
                                    direction = 1;
                                }
                                else if(playerVelocity.X < 0)
                                {
                                    direction = -1;
                                }
                            }

                            for (int i = 0; i < platformRec.Length; i++)
                            {
                                if (platformRec[i].Y >= screenHeight)
                                {
                                    platformLoc[i].Y -= screenHeight;
                                    platformLoc[i].X = rng.Next(100, 460);

                                    platformRec[i].X = (int)(platformLoc[i].X);
                                    platformRec[i].Y = (int)(platformLoc[i].Y);

                                    platTypeNum = rng.Next(1, 101);

                                    if (platTypeNum <= 70)
                                    {
                                        platformType[i] = REG;
                                    }
                                    else if (platTypeNum <= 80)
                                    {
                                        platformType[i] = MUD;
                                    }
                                    else if (platTypeNum <= 90)
                                    {
                                        platformType[i] = ICE;
                                    }
                                    else if (platTypeNum <= 100)
                                    {
                                        platformType[i] = SPIKE;
                                    }
                                }
                            }
                            //Check for the jump key, which is only allowed when on the ground

                            if (powerUp == false)
                            {

                                dTravelled += 1;

                                for (int i = 0; i < platformRec.Length; i++)
                                {
                                    if (BoxBoxCollision(playerFeetRec, platformRec[i]) == true)
                                    {
                                        switch (platformType[i])
                                        {
                                            case REG:
                                                {
                                                    friction = 0.1f;
                                                    Console.WriteLine("Set Friction for REG: " + friction);
                                                    jumpCounter = 0;
                                                    if (hitCounter == 0)
                                                    {
                                                        Increment();
                                                    }

                                                    if (playerVelocity.Y > 0)
                                                    {
                                                        playerVelocity.Y = platformSpeed.Y;
                                                        playerLoc.Y = platformRec[i].Y - playerRec.Height;
                                                    }
                                                }
                                                break;
                                            case MUD:
                                                {
                                                    friction = 0.2f;
                                                    jumpCounter = 0;
                                                    if (hitCounter == 0)
                                                    {
                                                        Increment();
                                                    }

                                                    if (playerVelocity.Y > 0)
                                                    {
                                                        playerVelocity.Y = platformSpeed.Y;
                                                        playerLoc.Y = platformRec[i].Y - playerRec.Height;
                                                    }
                                                }
                                                break;
                                            case ICE:
                                                {
                                                    friction = 0.2f;
                                                    jumpCounter = 0;
                                                    if (hitCounter == 0)
                                                    {
                                                        Increment();
                                                    }

                                                    if (playerVelocity.Y > 0)
                                                    {
                                                        playerVelocity.Y = platformSpeed.Y;
                                                        playerLoc.Y = platformRec[i].Y - playerRec.Height;
                                                    }
                                                }
                                                break;
                                            case SPIKE:
                                                {
                                                    jumpCounter = 0;

                                                    if (playerVelocity.Y > 0)
                                                    {
                                                        playerVelocity.Y += -30;
                                                        lives = lives - 1;
                                                    }
                                                }
                                                break;
                                        }

                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Reset Friction");
                                        friction = 0;

                                        if (playerVelocity.Y != 0)
                                        {
                                            playerVelocity.Y = playerVelocity.Y + gravity.Y;
                                        }

                                    }
                                }

                                if (jumpBarRec.Height >= 80)
                                {
                                    jumpsAvailable = 2;
                                }

                                if (((kb.IsKeyDown(Keys.Space) && !prevKb.IsKeyDown(Keys.Space))) && jumpCounter < jumpsAvailable)
                                {
                                    hitCounter = 0;
                                    playerVelocity.Y += jumpSpeed;
                                    jumpCounter++;

                                    if (jumpCounter == 2)
                                    {
                                        jumpBarRec.Height = jumpBarRec.Height - 50;
                                        jumpBarRec.Y = jumpBarRec.Y + 50;
                                        jumpsAvailable = 1;
                                    }

                                }

                                if (lives >= 0)
                                {
                                    for (int i = 0; i < leftWallSpikesRec.Length; i++)
                                    {
                                        if (BoxBoxCollision(playerRec, leftWallSpikesRec[i]))
                                        {
                                            if (spikeWallHitCounter == 0)
                                            {
                                                lives -= 1;
                                            }

                                            playerVelocity.X = 0;
                                            playerVelocity.Y = 0;

                                            playerVelocity.X += 10;
                                            playerVelocity.Y += -10;

                                            spikeWallHitCounter++;
                                        }
                                        else if (BoxBoxCollision(playerRec, rightWallSpikesRec[i]))
                                        {
                                            if (spikeWallHitCounter == 0)
                                            {
                                                lives -= 1;
                                            }

                                            playerVelocity.X = 0;
                                            playerVelocity.Y = 0;

                                            playerVelocity.X += -10;
                                            playerVelocity.Y += -10;
                                            spikeWallHitCounter++;
                                        }
                                        else
                                        {
                                            spikeWallHitCounter = 0;
                                        }

                                    }


                                    if (BoxBoxCollision(playerRec, lavaRec))
                                    {
                                        lives = 0;
                                    }
                                }
                                else if (lives <= 0)
                                {
                                    gameState = GAMEOVER;
                                }

                                if (playerLoc.Y >= 0)
                                {
                                    playerLoc = playerLoc + playerVelocity;
                                }
                                else
                                {
                                    playerLoc.Y = 1;
                                }

                                if (BoxBoxCollision(playerRec, powerUpRec))
                                {
                                    powerUpRec.X = rng.Next(120, 480);
                                    powerUpRec.Y = rng.Next(-800, 0);
                                    powerUp = true;
                                }
                            }

                            if (powerUp == true)
                            {
                                powerBarRec.Y += 1;
                                powerBarRec.Height += -1;
                                score += 10;
                                platformSpeed.Y = 6f;
                                scrollingSpeed = 4;
                                dTravelled += 2;

                                if (powerBarRec.Height <= 0)
                                {
                                    powerBarRec.Y = 200;
                                    powerBarRec.Height = 200;
                                    platformSpeed.Y = 2f;
                                    scrollingSpeed = 1;
                                    powerUp = false;
                                }
                            }

                            if (Math.Abs(playerVelocity.X) < 0.2)
                            {
                                playerVelocity.X = 0;
                                direction = 0;
                            }

                            Console.WriteLine("Direction: " + direction + ", friction: " + friction);
                            playerVelocity.X = playerVelocity.X + (-direction * friction);

                            playerRec.X = (int)(playerLoc.X);
                            playerRec.Y = (int)(playerLoc.Y);
                            playerFeetRec.X = playerRec.X + 12;
                            playerFeetRec.Y = playerRec.Y + 60;

                            SetPlatformLoc();

                            powerUpLoc.Y += 2f;

                            powerUpRec.X = (int)(powerUpLoc.X);
                            powerUpRec.Y = (int)(powerUpLoc.Y);

                            healthUpLoc.Y += 2f;

                            healthUpRec.X = (int)(healthUpLoc.X);
                            healthUpRec.Y = (int)(healthUpLoc.Y);

                            if (BoxBoxCollision(powerUpRec, lavaRec))
                            {
                                powerUpLoc.X = rng.Next(100, 460);
                                powerUpLoc.Y = rng.Next(-1000, -500);
                            }
                            if (BoxBoxCollision(healthUpRec, lavaRec))
                            {
                                healthUpLoc.X = rng.Next(100, 460);
                                healthUpLoc.Y = rng.Next(-1000, -500);
                            }

                            highScore = score;

                            //Console.WriteLine(lives);
                            //Console.WriteLine(direction);


                            if (lives > 0 && lives < 3)
                            {
                                if (BoxBoxCollision(playerRec, healthUpRec))
                                {
                                    lives = lives + 1;
                                }
                            }

                            if(kb.IsKeyDown(Keys.P) && !prevKb.IsKeyDown(Keys.P))
                            {
                                pause = true;
                            }
                        }
                        else
                        {
                            if (kb.IsKeyDown(Keys.P) && !prevKb.IsKeyDown(Keys.P))
                            {
                                pause = false;
                            }

                            if(kb.IsKeyDown(Keys.Back) && !prevKb.IsKeyDown(Keys.Back))
                            {
                                gameState = MAIN_MENU;
                            }
                        }

                    }
                    break;
                case GAMEOVER:
                    {

                    }
                    break;
                case POSTGAME:
                    {

                    }
                    break;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            switch (gameState)
            {
                case MAIN_MENU:
                    {
                        spriteBatch.Draw(titleBgImg, titleBgRec, Color.White);

                        for (int i = 0; i < selectionBoxRec.Length; i++)
                        {
                            spriteBatch.Draw(blackBoxImg, selectionBoxRec[i], Color.White);
                        }

                        spriteBatch.DrawString(gameLabel, instructionsOutput, instructionsLoc, Color.White);
                        spriteBatch.DrawString(gameLabel, optionsOutput, optionsLoc, Color.White);
                        spriteBatch.DrawString(gameLabel, scoreboardOutput, scoreboardLoc, Color.White);
                        spriteBatch.DrawString(gameLabel, startGameOutput, startGameLoc, Color.White);
                    }
                    break;
                case INSTRUCTIONS:
                    {
                        spriteBatch.Draw(instructionsBgImg, instructionsBgRec, Color.White);
                        spriteBatch.Draw(backArrowImg, backArrowRec, Color.White);
                    }
                    break;
                case OPTIONS:
                    {
                        spriteBatch.Draw(optionsBgImg, optionsBgRec, Color.White);
                        spriteBatch.Draw(plusImg, plusRec, Color.White);
                        spriteBatch.Draw(minusImg, minusRec, Color.White);
                        spriteBatch.DrawString(gameLabel, "" + audioVolume, audioVolumeLoc, Color.White);
                        spriteBatch.DrawString(gameLabel, "Move Left", moveLeftLoc, Color.White);
                        spriteBatch.DrawString(gameLabel, "Move Right", moveRightLoc, Color.White);
                        spriteBatch.DrawString(gameLabel, "Jump Up", jumpLoc, Color.White);
                        spriteBatch.Draw(backArrowImg, backArrowRec, Color.White);
                    }
                    break;
                case SCOREBOARD:
                    {
                        spriteBatch.Draw(backArrowImg, backArrowRec, Color.White);
                    }
                    break;
                case GAMEPLAY:
                    {

                        spriteBatch.Draw(gameplayBgImg, gameplayBgRec1, Color.White);
                        spriteBatch.Draw(gameplayBgImg, gameplayBgRec2, Color.White);

                        if (powerUp == true)
                        {
                            spriteBatch.Draw(playerImg, playerRec, Color.White * 0.5f);
                        }
                        else
                        {
                            spriteBatch.Draw(playerImg, playerRec, Color.White);
                        }
                        
                        for (int i = 0; i < platformRec.Length; i++)
                        {
                            switch (platformType[i])
                            {
                                case REG:
                                    {
                                        spriteBatch.Draw(platformImg, platformRec[i], Color.White);
                                    }
                                    break;
                                case MUD:
                                    {
                                        spriteBatch.Draw(mudPlatformImg, platformRec[i], Color.White);
                                    }
                                    break;
                                case ICE:
                                    {
                                        spriteBatch.Draw(iceyPlatformImg, platformRec[i], Color.White);
                                    }
                                    break;
                                case SPIKE:
                                    {
                                        spriteBatch.Draw(spikesPlatformImg, platformRec[i], Color.White);
                                    }
                                    break;
                            }
                        }

                        spriteBatch.Draw(blankImg, playerFeetRec, Color.White);


                        for (int i = 0; i < leftWallSpikesRec.Length; i++)
                        {
                            spriteBatch.Draw(leftWallSpikesImg, leftWallSpikesRec[i], Color.White);
                        }

                        for (int i = 0; i < rightWallSpikesRec.Length; i++)
                        {
                            spriteBatch.Draw(rightWallSpikesImg, rightWallSpikesRec[i], Color.White);
                        }



                        if (lives == 3)
                        {
                            for (int i = 0; i < livesRec.Length; i++)
                            {
                                spriteBatch.Draw(livesImg, livesRec[i], Color.White);
                            }
                        }
                        else if (lives == 2)
                        {
                            spriteBatch.Draw(livesImg, livesRec[2], Color.White * 0.5f);
                            spriteBatch.Draw(livesImg, livesRec[1], Color.White);
                            spriteBatch.Draw(livesImg, livesRec[0], Color.White);
                        }
                        else if (lives == 1)
                        {

                            spriteBatch.Draw(livesImg, livesRec[2], Color.White * 0.5f);
                            spriteBatch.Draw(livesImg, livesRec[1], Color.White * 0.5f);
                            spriteBatch.Draw(livesImg, livesRec[0], Color.White);
                        }
                        else
                        {
                            for (int i = 0; i < livesRec.Length; i++)
                            {
                                spriteBatch.Draw(livesImg, livesRec[i], Color.White * 0.5f);
                            }
                        }

                        spriteBatch.Draw(leftWallImg, leftWallRec, Color.White);
                        spriteBatch.Draw(rightWallImg, rightWallRec, Color.White);
                        spriteBatch.Draw(lavaImg, lavaRec, Color.White);
                        spriteBatch.DrawString(gameLabel, scoreOutput + score, scoreLoc, Color.White);
                        spriteBatch.DrawString(gameLabel, highScoreOutput + highScore, highScoreLoc, Color.White);
                        spriteBatch.DrawString(gameLabel, dTravelledOutput + dTravelled, dTravelledLoc, Color.White);
                        spriteBatch.Draw(blankImg, jumpBarOutline, Color.White);
                        spriteBatch.Draw(jumpBarImg, jumpBarRec, Color.White);
                        spriteBatch.Draw(blankImg, powerBarOutline, Color.White);
                        spriteBatch.Draw(powerBarImg, powerBarRec, Color.White);
                        spriteBatch.Draw(powerUpImg, powerUpRec, Color.White);
                        spriteBatch.Draw(healthUpImg, healthUpRec, Color.White);
                        //spriteBatch.Draw(blankImg, pSpikesRec, Color.White);

                        if(pause == true)
                        {
                            spriteBatch.Draw(whitePageImg, whiteRec, Color.Black * 0.5f);
                            spriteBatch.DrawString(gameLabel, pauseOutput, pauseLoc, Color.Red);
                        }
                    }
                    break;
                case GAMEOVER:
                    {

                    }
                    break;
                case POSTGAME:
                    {

                    }
                    break;
            }

            spriteBatch.End();
            base.Draw(gameTime);
        }

        //Pre: r1 and r2 are two valid rectangles
        //Post: Return true if r1 intersects with r2 in any way, false otherwise
        //Description: Determine if r1 intersects with r2 by checking for impossible collisions
        private bool BoxBoxCollision(Rectangle box1, Rectangle box2)
        {
            //If any one of the four impossiblities is true there is no collision
            if (box1.Right < box2.Left || box1.Left > box2.Right ||
                box1.Bottom < box2.Top || box1.Top > box2.Bottom)
            {
                return false;
            }
            else
            {
                //All impossibilities failed, so it MUST be a collision
                return true;
            }
        }
        private bool NewMouseClick()
        {
            //When the left button of the mouse is pressed and the left button was not previously pressed
            if (mouse.LeftButton == ButtonState.Pressed && prevMouse.LeftButton != ButtonState.Pressed)
            {
                //A new mouse click has occured
                return true;
            }

            //No new mouse click has occured
            return false;
        }

        //Pre: Rectangle
        //Post: Returns a bool variable 
        //Desc: Determines whether the x and y coordinates of the mouse where
        //within the x and y coordinates of the Rectangle being tested
        private bool MouseClicked(Rectangle box)
        {
            //When the mouses location is within the x,y coordinates, length and width of the box
            if (mouse.X <= box.X + box.Width && mouse.X >= box.X && mouse.Y <= box.Y + box.Height && mouse.Y >= box.Y)
            {
                //Mouse was within the box
                return true;
            }
            else
            {
                //Mouse was not within the box
                return false;
            }
        }
        private void ResetGame()
        {

        }
        private void ScrollScreen()
        {
            gameplayBgRec1.Y += scrollingSpeed;
            gameplayBgRec2.Y += scrollingSpeed;


            if (gameplayBgRec1.Y >= screenHeight)
            {
                gameplayBgRec1.Y = -screenHeight;
            }

            if (gameplayBgRec2.Y >= screenHeight)
            {
                gameplayBgRec2.Y = -screenHeight;
            }
        }

        private void HorizontalMovement()
        {
            if (kb.IsKeyDown(Keys.Right))
            {
                if (playerVelocity.X < maxSpeed)
                {
                    playerVelocity.X += acceleration;
                    
                }

            }
            else if (kb.IsKeyDown(Keys.Left))
            {
                if (playerVelocity.X < maxSpeed)
                {
                    playerVelocity.X -= acceleration;
                    
                }
            }

            /*if (!kb.IsKeyDown(Keys.Left) && !kb.IsKeyDown(Keys.Right))
            {
                playerVelocity.X = 0;
            }*/
        }
        private void IncreaseDifficulty()
        {
            if (difficultyTimer >= (4.9 + (difficulty)) && difficultyTimer < (5.1 + (difficulty)))
            {
                platformSpeed.Y += 0.1f;
                difficulty+= 10;
            }
        }
        private void SetPlatformLoc()
        {
            platformLoc[0] = platformLoc[0] + platformSpeed;
            platformRec[0].X = (int)(platformLoc[0].X);
            platformRec[0].Y = (int)(platformLoc[0].Y);

            platformLoc[1] = platformLoc[1] + platformSpeed;
            platformRec[1].X = (int)(platformLoc[1].X);
            platformRec[1].Y = (int)(platformLoc[1].Y);

            platformLoc[2] = platformLoc[2] + platformSpeed;
            platformRec[2].X = (int)(platformLoc[2].X);
            platformRec[2].Y = (int)(platformLoc[2].Y);

            platformLoc[3] = platformLoc[3] + platformSpeed;
            platformRec[3].X = (int)(platformLoc[3].X);
            platformRec[3].Y = (int)(platformLoc[3].Y);

            platformLoc[4] = platformLoc[4] + platformSpeed;
            platformRec[4].X = (int)(platformLoc[4].X);
            platformRec[4].Y = (int)(platformLoc[4].Y);
        }
        private void Increment()
        {
            score += 100;
            hitCounter++;

            if (jumpBarRec.Height <= 190)
            {
                jumpBarRec.Y = jumpBarRec.Y - 10;
                jumpBarRec.Height = jumpBarRec.Height + 10;
            }

        }
    }
}
